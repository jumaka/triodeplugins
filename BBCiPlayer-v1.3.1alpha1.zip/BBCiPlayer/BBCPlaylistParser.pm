package Plugins::BBCiPlayer::BBCPlaylistParser;

# This module is no longer used and is only included for backwards compatibility

use strict;

use Slim::Utils::Log;

use XML::Simple;
use Date::Parse;

my $log = logger('plugin.bbciplayer');

sub parse {
    my $class  = shift;
    my $http   = shift;

    my $params = $http->params('params');
    my $url    = $params->{'url'};

	my $xml = eval { XMLin( $http->contentRef, ForceArray => ['link'] ) };

	if ($@) {
		$log->error("$@");
		return;
	}

	my $icon;

	if ($xml->{'link'} && ref $xml->{'link'} eq 'ARRAY') {

		for my $link (@{$xml->{'link'}}) {

			if ($link->{'type'} && $link->{'type'} =~ /image/ && $link->{'href'}) {
				$icon = $link->{'href'};
			}
		}
	}

	$http->params('params')->{'parser'} =~ s/BBCPlaylistParser/BBCMSParser/;

	$http->params('params')->{'item'}->{'icon'} = $icon if $icon;
	$http->params('params')->{'item'}->{'description'} = $xml->{'summary'} if $xml->{'summary'};
		
	if ($xml->{'item'} && $xml->{'item'}->{'media'} && $xml->{'item'}->{'media'}->{'connection'}) {

		my $con = $xml->{'item'}->{'media'}->{'connection'};

		my $url = "http://www.bbc.co.uk/mediaselector/4/gtis/?server=$con->{server}&identifier=$con->{identifier}";

		if ($con->{'application'}) {
			$url .= "&application=$con->{application}";
		}

		return {
			url  => $url,
			type => 'redirect',
		};
	}
}

1;
