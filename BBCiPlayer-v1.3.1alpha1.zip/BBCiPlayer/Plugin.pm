package Plugins::BBCiPlayer::Plugin;

# Plugin to play live and on demand BBC radio streams
# (c) Triode, 2007-2011, triode1@btinternet.com
#
# Released under GPLv2

use strict;

use base qw(Slim::Plugin::OPMLBased);

use File::Spec::Functions qw(:ALL);
use Slim::Utils::Prefs;
use Slim::Utils::Log;

use Plugins::BBCiPlayer::iPlayer;
use Plugins::BBCiPlayer::RTMP;
use Plugins::BBCiPlayer::HLS;

my $prefs = preferences('plugin.bbciplayer');

my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.bbciplayer',
	'defaultLevel' => 'ERROR',
	'description'  => getDisplayName(),
});

my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.bbciplayer.rtmp',
	'defaultLevel' => 'ERROR',
	'description'  => getDisplayName(),
});

my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.bbciplayer.hls',
	'defaultLevel' => 'ERROR',
	'description'  => getDisplayName(),
});

my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.bbciplayer.livetxt',
	'defaultLevel' => 'ERROR',
	'description'  => getDisplayName(),
});

sub initPlugin {
	my $class = shift;

	$prefs->init({ prefOrder_live => 'aac,flashaac,flashmp3,wma', prefOrder_aod => 'aac,flashaac,flashmp3,wma', transcode => 1, 
				   radiovis_txt => 1, radiovis_slide => 0, livetxt_classic_line => 0, is_app => 0 });

	my $file = catdir( $class->_pluginDataFor('basedir'), 'menu.opml' );

	$class->SUPER::initPlugin(
		feed   => Slim::Utils::Misc::fileURLFromPath($file),
		tag    => 'bbciplayer',
		is_app => $class->can('nonSNApps') && $prefs->get('is_app') ? 1 : undef,
		menu   => 'radios',
		weight => 1,
	);

	if (!$::noweb) {
		require Plugins::BBCiPlayer::Settings;
		Plugins::BBCiPlayer::Settings->new;
	}
}

sub getDisplayName { 'PLUGIN_BBCIPLAYER' }

sub playerMenu { shift->can('nonSNApps') && $prefs->get('is_app') ? undef : 'RADIO' }

1;
