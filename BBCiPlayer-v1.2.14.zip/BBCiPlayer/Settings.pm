package Plugins::BBCiPlayer::Settings;

use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Prefs;

sub name {
	return 'PLUGIN_BBCIPLAYER';
}

sub page {
	return 'plugins/BBCiPlayer/settings/basic.html';
}

sub prefs {
	return (preferences('plugin.bbciplayer'), qw(prefOrder_live prefOrder_aod transcode
												 radiovis_txt radiovis_slide livetxt_classic_line 
												 is_app));
}

sub beforeRender {
	my $class = shift;
	my $params= shift;

	if ($params->{'prefs'}->{'pref_prefOrder_live'} =~ /flash/ || $params->{'prefs'}->{'pref_prefOrder_aod'} =~ /flash/) {
		require Plugins::BBCiPlayer::RTMP;
	}

	$params->{'show_app'} = Slim::Plugin::Base->can('nonSNApps');

	my %fmtmap = (
		aac      => 'AAC',
		flashaac => 'FlashAAC',
		flashmp3 => 'FlashMP3',
		wma      => 'WMA',
	);

	my @opts = (
		'aac,flashaac,flashmp3,wma',
		'aac,flashaac,wma',
		'aac,flashaac',
		'aac,wma',
		'flashaac,wma',
		'wma',
	);

	my @prefOpts = ();

	for my $opt (@opts) {
		push @prefOpts, { opt => $opt, disp => join(" > ", map { $fmtmap{$_} } split(/,/, $opt)) };
	}

	$params->{'opts'} = \@prefOpts;
}

1;
