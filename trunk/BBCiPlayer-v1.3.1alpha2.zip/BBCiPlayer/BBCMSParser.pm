package Plugins::BBCiPlayer::BBCMSParser;

# This module is no longer used and is only included for backwards compatiblity

use strict;

use XML::Simple;
use HTML::Entities;

use Slim::Utils::Log;
use Slim::Utils::Prefs;

use constant TTL_EXPIRE => 10;

my $log   = logger('plugin.bbciplayer');
my $prefs = preferences('plugin.bbciplayer');

sub parse {
    my $class  = shift;
    my $http   = shift;
	my $optstr = shift;

    my $params = $http->params('params');
    my $url    = $params->{'url'};
	my $client = $params->{'client'};

	my $item = $params->{'item'};
	my $title = $item->{'streamtitle'} || $item->{'name'} || $item->{'title'} || $params->{'feedTitle'};
	my $icon = $item->{'icon'};
	my $desc = $item->{'description'};
	my $dur  = $item->{'dur'};

	my $livetxt;
	my $aacpl;

	if ($optstr) {
		if ($optstr =~ /livetxt=(.*)&aacpl=(.*)/) {
			($livetxt, $aacpl) = ($1, $2);
		} elsif ($optstr =~ /aacpl=(.*)/) {
			$aacpl = $1;
		} else {
			$livetxt = $optstr;
		}
	}

	$icon =~ s/178_100/512_288/;

	my $aac = 0;

	my @playerFormats = exists &Slim::Player::CapabilitiesHelper::supportedFormats 
		? Slim::Player::CapabilitiesHelper::supportedFormats($client) 
		: $client->formats;

	for my $format (@playerFormats) {
		if ($format eq 'aac' || 
			(exists &Slim::Player::TranscodingHelper::checkBin && Slim::Player::TranscodingHelper::checkBin("aac-$format-*-*")) ) {
			$aac = 1;
			last;
		}
	}

	my $stream = $class->_findStream({
		contentref => $http->contentRef, icon => $icon, desc => $desc, dur => $dur, url => $url, aac => $aac, livetxt => $livetxt
	});

	return {
		'type'  => 'opml',
		'items' => [ {
			'name' => $title,
			'url'  => $stream,
			'type' => 'audio',
			'icon' => $icon,
			'description' => $desc,
		} ],
		'cachetime' => 0,
		'replaceparent' => 1,
	};
}

sub _findStream {
	my $class = shift;
	my $args  = shift;

	my $xml = eval { XMLin($args->{'contentref'}, KeyAttr => undef, ForceArray => 'media' ) };

	if ($@) {
		$log->error("$@");
		return;
	}

	my $services;
	my $stream;

	for my $media (@{$xml->{'media'}}) {

		if ($media->{'service'} && ref $media->{'connection'} eq 'ARRAY') {

			# last connection entry works for both local and national radio at present
			for my $key (keys %{$media->{'connection'}->[-1]}) {

				$media->{$key} = $media->{'connection'}->[-1]->{$key};
			}

			$services->{ $media->{'service'} } = $media;

			delete $media->{'connection'};
		}
	}

	my @streamPrefOrder;

	# don't use this as these urls are timebound and we have no mechanism to update when they go stale
	# push @streamPrefOrder, 'icy_uk_stream_aac_high_live';

	if ($prefs->get('prefer_wma')) {
		push @streamPrefOrder, (
			'iplayer_intl_stream_wma_live',        # WMA intl live stream
			'iplayer_uk_stream_wma',               # WMA uk stream
			'iplayer_intl_stream_wma',             # WMA intl stream
			'iplayer_intl_stream_wma_ws',          # WMA intl ws on demand
			'iplayer_intl_stream_wma_uk_concrete', # WMA uk listen again
			'iplayer_intl_stream_wma_lo_concrete', # WMA intl listen again
		);
	}

	if ($prefs->get('flashaac') && $args->{'aac'}) {
		push @streamPrefOrder, (
		'iplayer_uk_stream_aac_rtmp_hi_live',      # FlashAAC uk high bitrate live
		'iplayer_uk_stream_aac_rtmp_live',         # FlashAAC uk live
		'iplayer_uk_stream_aac_rtmp_concrete',     # FlashAAC uk on demand
		'iplayer_intl_stream_aac_rtmp_live',       # FlashAAC intl live
		'iplayer_intl_stream_aac_rtmp_concrete',   # FlashAAC intl on demand
		'iplayer_intl_stream_aac_rtmp_ws_live',    # FlashAAC intl ws live
		'iplayer_intl_stream_aac_ws_concrete',     # FlashAAC intl ws on demand
	   );
	}

	if ($prefs->get('flashmp3')) {
		push @streamPrefOrder, (
			'iplayer_uk_stream_mp3',               # FlashMP3 uk on demand
			'iplayer_intl_stream_mp3',             # FlashMP3 national on demand
			'iplayer_intl_stream_mp3_lo',          # FlashMP3 local radio on demand
		);
	}

	if (!$prefs->get('prefer_wma')) {
		push @streamPrefOrder, (
			'iplayer_intl_stream_wma_live',        # WMA intl live stream
			'iplayer_uk_stream_wma',               # WMA uk stream
			'iplayer_intl_stream_wma',             # WMA intl stream
			'iplayer_intl_stream_wma_ws',          # WMA intl ws on demand
			'iplayer_intl_stream_wma_uk_concrete', # WMA uk listen again
			'iplayer_intl_stream_wma_lo_concrete', # WMA intl listen again
		);
	}

	my $swf = '';
	
	for my $service (@streamPrefOrder) {

		my $entry = $services->{$service} || next;

		if ($service =~ /iplayer_(uk|intl)_stream_aac_rtmp_(hi_live|live|ws_live)/) {

			$stream = Plugins::BBCiPlayer::RTMP->packUrl({
				host       => $entry->{'server'},
				port       => 1935,
				swfurl     => $swf,
				streamname => "$entry->{identifier}?$entry->{authString}&aifp=v001",
				subscribe  => "$entry->{identifier}",
				tcurl      => "rtmp://$entry->{server}:1935/live?_fcs_vhost=$entry->{server}&$entry->{authString}",
				app        => "live?_fcs_vhost=$entry->{server}&$entry->{authString}",
				live       => 1,
				livetxt    => $args->{'livetxt'},
				ct         => 'aac',
				br         => $entry->{'bitrate'},
				icon       => $args->{'icon'},
				desc       => $args->{'desc'},
				url        => $args->{'url'},
				update     => __PACKAGE__,
				ttl        => time() + TTL_EXPIRE,
			});

		} elsif ($service =~ /iplayer_(uk|intl)_stream_aac_rtmp_concrete/) {

			$stream = Plugins::BBCiPlayer::RTMP->packUrl({
				host       => $entry->{'server'},
				port       => 1935,
				swfurl     => $swf,
				streamname => "$entry->{identifier}",
				tcurl      => "rtmp://$entry->{server}:1935/$entry->{application}?$entry->{authString}",
				app        => "$entry->{application}?$entry->{authString}",
				ct         => 'aac',
				br         => $entry->{'bitrate'},
				icon       => $args->{'icon'},
				desc       => $args->{'desc'},
				url        => $args->{'url'},
				duration   => $args->{'dur'},
				update     => __PACKAGE__,
				ttl        => time() + TTL_EXPIRE,
			});

		} elsif ($service =~ /iplayer_intl_stream_aac_ws_concrete/) {

			$stream = Plugins::BBCiPlayer::RTMP->packUrl({
				host       => $entry->{'server'},
				port       => 1935,
				swfurl     => $swf,
				streamname => "$entry->{identifier}?$entry->{authString}",
				tcurl      => "rtmp://$entry->{server}:1935/ondemand?_fcs_vhost=$entry->{server}&$entry->{authString}",
				app        => "ondemand?_fcs_vhost=$entry->{server}&$entry->{authString}",
				ct         => 'aac',
				br         => $entry->{'bitrate'},
				icon       => $args->{'icon'},
				desc       => $args->{'desc'},
				url        => $args->{'url'},
				duration   => $args->{'dur'},
				update     => __PACKAGE__,
				ttl        => time() + TTL_EXPIRE,
			});

		} elsif ($service =~ /iplayer_uk_stream_mp3|iplayer_intl_stream_mp3|iplayer_intl_stream_mp3_lo/) {

			$stream = Plugins::BBCiPlayer::RTMP->packUrl({
				host       => $entry->{'server'},
				port       => 1935,
				swfurl     => $swf,
				streamname => "$entry->{identifier}?$entry->{authString}",
				tcurl      => "rtmp://$entry->{server}:1935/ondemand?_fcs_vhost=$entry->{server}&$entry->{authString}",
				app        => "ondemand?_fcs_vhost=$entry->{server}&$entry->{authString}",
				ct         => 'mp3',
				br         => $entry->{'bitrate'},
				icon       => $args->{'icon'},
				desc       => $args->{'desc'},
				url        => $args->{'url'},
				duration   => $args->{'dur'},
				update     => __PACKAGE__,
				ttl        => time() + TTL_EXPIRE,
			});

		} elsif ($entry->{'href'}) {

			$stream = $entry->{'href'};

			if ($args->{'livetxt'}) {
				
				$stream .= "?livetxt=$args->{livetxt}";
			}

			if ($args->{'icon'}) {

				my $cache;
				
				if (Slim::Utils::Versions->compareVersions($::VERSION, '7.6') >= 0) {
					$cache = Slim::Utils::Cache->new();
				} else {
					$cache = Slim::Utils::Cache->new('Artwork', 1, 1);
				}
				
				$cache->set("remote_image_$stream", $args->{'icon'}, '360000');
			}
		}

		if ($stream) {
			$log->info("Found stream for $service from $args->{url}: $stream");
			last;
		};
	}

	# experimental addition for special event streams:
	if (!$stream && $xml->{'identifier'} && ref $xml->{'identifier'} eq 'ARRAY' && $xml->{'identifier'}->[0]) {
		
		my $server = $xml->{'server'}->[0];
		my $ident  = $xml->{'identifier'}->[0];
		my $auth   = $xml->{'token'}->[0];
		my $app    = $xml->{'application'}->[0];
		
		$stream = Plugins::BBCiPlayer::RTMP->packUrl({
			host       => $server,
			port       => 1935,
			swfurl     => $swf,
			streamname => "$ident?$auth",
			subscribe  => $app eq 'live' ? $ident : undef,
			tcurl      => "rtmp://$server:1935/$app?_fcs_vhost=$server&$auth",
			app        => "$app?_fcs_vhost=$server&$auth",
			live       => $app eq 'live' ? 1 : undef,
			livetxt    => $args->{'livetxt'},
			ct         => 'aac',
			icon       => $args->{'icon'},
			desc       => $args->{'desc'},
			url        => $args->{'url'},
			update     => __PACKAGE__,
			ttl        => time() + TTL_EXPIRE,
		});

	}		

	if (!$stream) {
		$log->info("No stream found in $args->{url}");
	}

	return $stream;
}

sub update {
	my $class = shift;
	my $song  = shift;
	my $params= shift;
	my $cb    = shift;
	my $ecb   = shift;

	Slim::Networking::SimpleAsyncHTTP->new(
		\&_updateCB, \&_updateECB, { song => $song, params => $params, cb => $cb, ecb => $ecb }
	)->get( $params->{'url'} );
}

sub _updateCB {
	my $http = shift;
	my $song = $http->params('song');
	my $p    = $http->params('params');
	my $cb   = $http->params('cb');

	$log->info("updating streamUrl with new data from $p->{url}");

	my $aac = $p->{'ct'} eq 'aac' ? 1 : 0;

	my $stream = __PACKAGE__->_findStream({ 
		contentref => $http->contentRef, icon => $p->{'icon'}, desc => $p->{'desc'}, dur => $p->{'duration'}, url => $p->{'url'},
		aac => $aac, livetxt => $p->{'livetxt'},
	});

	$song->streamUrl($stream);
	
	$cb->();
}

sub _updateECB {
	my $http = shift;
	my $ecb  = $http->params('ecb');

	$log->warn("unable to fetch xml feed: " . $http->url);

	$ecb->();
}

1;
