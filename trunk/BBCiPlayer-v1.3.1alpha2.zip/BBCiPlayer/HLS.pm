package Plugins::BBCiPlayer::HLS;

# HLS protocol handler
#
# (c) Triode, 2015, triode1@btinternet.com
#
# Released under GPLv2

use strict;

use base qw(IO::Handle);

use Slim::Utils::Errno;
use Slim::Utils::Log;

use bytes;

use constant FETCH_CHUNKS => 5; # number of chunks to prefetch

my $log = logger('plugin.bbciplayer.hls');

Slim::Player::ProtocolHandlers->registerHandler('hls', __PACKAGE__);

sub new {
	my $class = shift;
	my $args = shift;

	my $song     = $args->{'song'};
	my $url      = ($song->can('streamUrl') ? $song->streamUrl : $song->{'streamUrl'}) || $args->{'url'};
	my $seekdata = $song->can('seekdata') ? $song->seekdata : $song->{'seekdata'};
	my $start    = $seekdata->{'timeOffset'};

	if ($start) {
		if($song->can('startOffset')) {
			$song->startOffset($start);
		} else {
			$song->{startOffset} = $start;
		}
		$args->{'client'}->master->remoteStreamStartTime(Time::HiRes::time() - $start);
	}

	$url =~ s/^hls/http/;
	$url =~ s/xx$//;

	$log->debug("open $url $start");

	my $self = $class->SUPER::new;

	${*$self}{'song'} = $song;
	${*$self}{'baseurl'} = $url;
	${*$self}{'_chunks'} = [];
	${*$self}{'_adtslen'} = 0;
	${*$self}{'_adtspid'} = 0;
	${*$self}{'_pl_url'}  = "";
	${*$self}{'_pl_noupdate'} = 0;
	${*$self}{'_pl_fetched'} = 0;
	${*$self}{'_pl_lastint'} = 0;
	${*$self}{'_played'} = 0;

	$self->_fetchPL($url, $start);

	return $self;
}

sub _fetchPL {
	my $self = shift;
	my $url  = shift;
	my $start= shift || 0;

	$log->debug("fetch playlist: $url start: $start");

	${*$self}{'_pl_fetched'} = time();

	Slim::Networking::SimpleAsyncHTTP->new(
		\&_parsePL, 
		sub { 
			$log->warn("error fetching $url");
			$self->close; 
		}, 
		{ obj => $self, url => $url, start => $start, cache => 0 },
	)->get($url);
}

sub _parsePL {
	my $http = shift;
	my $self = $http->params('obj');
	my $url  = $http->params('url');
	my $start= $http->params('start');

	$log->debug("got: $url start: $start");

	${*$self}{'_pl_url'} = $url;

	my @lines = split(/\n/, $http->content);

	my $line1 = shift @lines;
	if ($line1 !~ /#EXTM3U/) {
		$log->warn("bad m3u file: $url");
		$self->close;
		return;
	}

	my $duration;
	my $chunknum;
	my @chunks = ();

	while (my $line = shift @lines) {

		if ($line =~ /#EXT-X-STREAM-INF:(.*)/) {
			foreach my $params (split(/,/, $1)) {
				if ($params =~ /BANDWIDTH=(\d+)/) {
					$log->debug("bandwidth: $1");
					my $stream = ${*$self}{'song'}->streamUrl;
					my $track  = Slim::Schema::RemoteTrack->fetch($stream);
					$track->bitrate($1);
				}
			}

			my $redurl = shift @lines;
			$log->debug("redirect: $redurl");
			$self->_fetchPL($redurl, $start);
			return;
		}

		if ($line =~ /#EXT-X-MEDIA-SEQUENCE:(\d+)/) {
			$log->debug("#EXT-X-MEDIA-SEQUENCE: $1");
			$chunknum = $1;
			next;
		}

		if ($line =~ /#EXT-X-ALLOW-CACHE:YES/) {
			$log->debug("#EXT-X-ALLOW-CACHE:YES");
			$duration = 0;
		}

		if ($line =~ /#EXT-X-ENDLIST/) {
			$log->debug("#EXT-X-ENDLIST");
			${*$self}{'_pl_noupdate'} = 1;
		}

		if ($line =~ /#EXTINF:(.*),/) {
			if (defined($duration)) {
				$duration += $1;
			}

			${*$self}{'_pl_lastint'} = $1;

			my $chunkurl = shift @lines;

			if ($chunkurl !~ /^http:/) {
				# relative url
				$log->debug("relative url: $chunkurl");
				my ($urlbase) = $url =~ /(.*)\//;
				$chunkurl = $urlbase . "/" . $chunkurl;
				$log->debug("conveted to: $chunkurl");
			}

			if ($chunknum > ${*$self}{'_played'} && (!$start || !defined($duration) || $duration > $start)) {
				push @chunks, { url => $chunkurl, chunknum => $chunknum, len => $1 };
			}
			$chunknum++;
		}
	}

	${*$self}{'song'}->duration($duration) if defined $duration;

	$log->info(sub { "existing chunks: [" . join(",", map { $_->{'chunknum'} } @{${*$self}{'_chunks'}}) . "]" });

	$log->info(sub { "new chunks: [" . join(",", map { $_->{'chunknum'} } @chunks) . "]" });

	if (scalar @chunks) {

		if (scalar @{${*$self}{'_chunks'}} > 0) {
			
			# only add on chunks which and more recent than existing chunk list
			for my $new (@chunks) {
				if ($new->{'chunknum'} > ${*$self}{'_chunks'}->[-1]->{'chunknum'}) {
					push @{${*$self}{'_chunks'}}, $new;
				};
			}

			$log->info("merged chunklist now " . scalar @{${*$self}{'_chunks'}} . " chunks");

			$log->info(sub { "chunks: [" . join(",", map { $_->{'chunknum'} } @{${*$self}{'_chunks'}}) . "]" });

		} else {

			# new chunklist - fetch first 3 chunks
			${*$self}{'_chunks'} = \@chunks;

			$log->debug("new chunklist " . scalar @chunks . " chunks");

			for my $i(0 .. FETCH_CHUNKS - 1) {
				$self->_fetchChunk($chunks[$i]) if $chunks[$i];
			}

		}
	}
}

sub _fetchChunk {
	my $self  = shift;
	my $chunk = shift;

	if (my $url = $chunk->{'url'}) {
		$log->debug("fetching [$chunk->{chunknum}]: $url");
		$chunk->{'fetching'} = 1;
		Slim::Networking::SimpleAsyncHTTP->new(
			sub {
				$log->debug("got [$chunk->{chunknum}] size " . length($_[0]->content));
				delete $chunk->{'fetching'}; 
				$chunk->{'chunk'} = $_[0]->content;
			},
			sub { 
				$log->warn("error fetching [$chunk->{chunknum}] $url");
				delete $chunk->{'fetching'};
			}, 
		)->get($url);
	}
}

sub isRemote { 1 }

sub isAudio { 1 }

sub canSeek { 
	my ($class, $client, $song) = @_;

	return 1; #$song->duration ? 1 : 0;
}

sub getSeekData {
	my ($class, $client, $song, $newtime) = @_;
	
	return { timeOffset => $newtime };
}

sub contentType { 'aac' }

sub formatOverride { 'aac' }

sub getIcon {
	my ($class, $url) = @_;

	my $handler;

	if ( ($handler = Slim::Player::ProtocolHandlers->iconHandlerForURL($url)) && ref $handler eq 'CODE' ) {
		return &{$handler};
	}
	
	return Plugins::BBCiPlayer::Plugin->_pluginDataFor('icon');
}

#sub getMetadataFor {
#	my $class  = shift;
#	my $client = shift;
#	my $url    = shift;
#
#	return {}
#}

sub close {
	my $self = shift;
	${*$self}{'_close'} = 1;
}

sub sysread {
	my $self  = $_[0];
	# return in $_[1]
	my $maxBytes = $_[2];

	my $ret;

	# return 0 on close
	# return data in $_[1] and bytes count
	# else 
	#	$! = EWOULDBLOCK; (using EINTR as EWOULDBLOCK puts $self on select assuming it is a filehandle)
	#	return undef;
	
	if (${*$self}{'_close'}) {
		$log->debug("closing");
		return 0;
	}

	my $chunks = ${*$self}{'_chunks'};
	my $chunk;

	if (scalar @$chunks) {
		$chunk = $chunks->[0]->{'chunk'};
	}

	#if (!scalar @$chunks) {
	#	$log->debug("no chunks left - closing");
	#	return 0;
	#}

	#if (!$chunk && !$chunks->[0]-{'fetching'}) {
	#	shift @$chunks;
	#	$chunk = $chunks->[0]->{'chunk'};
	#}

	if ($chunk) {
		my $adtspack = "";

		while (!$ret && length($chunk) >= 188 && length($adtspack) < $maxBytes - 188) {

			# The following extracts AAC ADTS from an Mpeg transport stream and assumes only one pid
			# FIXME - make this more generic and optimise to reduce string copies...
			my $fmt  = unpack("N", $chunk);
			my $pack = substr($chunk, 4, 184);

			$chunk = $chunks->[0]->{'chunk'} = substr($chunk, 188);

			my $sync = ($fmt & 0xff000000) >> 24;
			my $pusi = ($fmt & 0x00400000) ? 1 : 0;
			my $pid  = ($fmt & 0x001fff00) >> 8 ;
			my $afe  = ($fmt & 0x00000020) ? 1 : 0;
			my $cp   = ($fmt & 0x00000010) ? 1 : 0;
			my $cont = ($fmt & 0x0000000f);

			#printf("%X sync: $sync pusi: $pusi pid: %X afe: $afe cp: $cp cont: $cont\n", $fmt, $pid);

			if ($sync != 71) {
				#print "bad sync\n";
				next;
			}

			if ($afe) {
				my $len = unpack("C", $pack);
				$pack = substr($pack, 1 + $len);
				#print "skipping adaptation field len: $len\n";
			}

			if ($pusi) {
				# find PES header:
				if (substr($pack, 0, 3) eq "\x00\x00\x01") {
					my ($sid, $len) = unpack("xxxCn", $pack);
					#print "PES: sid: $sid len: $len\n";
					$pack = substr($pack, 6);
					
					if (((unpack("C", $pack) & 0xC0) == 0x80)) {
						my $hlen = unpack("xxC", $pack);
						#print "PES header len: $hlen\n";
						$pack = substr($pack, 3 + $hlen);
						$len -= (3 + $hlen);
					}
					
					my ($b1, $b2) = unpack("CC", $pack);
					#printf("header: %X %X\n", $b1, $b2);
					if (1) {#$b1 eq 0xFF && ($b2 & 0xF0) == 0xF0) {
						#print "AAC pid: $pid\n";
						${*$self}{'_adtslen'} = $len;
						${*$self}{'_adtspid'} = $pid;

						# FIXME - write partial adtspacket - why?
						if (length($adtspack)) {
							#print "partial adts\n";
							$_[1] = $adtspack;
							$ret = length($adtspack);
						}

						$adtspack = "";
					}
				} else {
					#print "skipping\n";
					next;
				}
			}

			if ($pid == ${*$self}{'_adtspid'} && length($pack)) {
				
				$adtspack = $adtspack . $pack;

				my $len = length($adtspack);

				if ($len == ${*$self}{'_adtslen'} || $len > $maxBytes + 188) { 
					${*$self}{'_adtslen'} -= $len;
					$_[1] = $adtspack;
					$ret = $len;
				}
			}
		}

		if (!length($chunk) ) {
			my $played = shift @$chunks;
			$log->info("played [$played->{chunknum}]");
			${*$self}{'_played'} = $played->{'chunknum'};
		}

		if ($ret) {
			# FIXME - fetch new chunk if < FETCH_CHUNKS available or being fetched
			for my $i (0 .. FETCH_CHUNKS) {
				my $new = $chunks->[$i];
				if ($new && !$new->{'chunk'} && !$new->{'fetching'}) {
					$self->_fetchChunk($new);
					last;
				}
			}
		}
		
	}

	# refetch playlist if not a fixed list
	if (!${*$self}{'_pl_noupdate'} && time() > ${*$self}{'_pl_fetched'} + ${*$self}{'_pl_lastint'}) {
		$self->_fetchPL(${*$self}{'_pl_url'});
	}
	
	return $ret if $ret;

	# otherwise come back later - use EINTR as we don't have a file handle to put on select
	$! = EINTR;
	return undef;
}

1;
