package Plugins::BBCiPlayer::Settings;

use strict;
use base qw(Slim::Web::Settings);

use Slim::Utils::Prefs;

sub name {
	return 'PLUGIN_BBCIPLAYER';
}

sub page {
	return 'plugins/BBCiPlayer/settings/basic.html';
}

sub prefs {
	return (preferences('plugin.bbciplayer'), qw(prefOrder_live prefOrder_aod transcode
												 radiovis_txt radiovis_slide livetxt_classic_line 
												 is_app));
}

sub beforeRender {
	my $class = shift;
	my $params= shift;

	if ($params->{'prefs'}->{'pref_prefOrder_live'} =~ /flash/ || $params->{'prefs'}->{'pref_prefOrder_aod'} =~ /flash/) {
		require Plugins::BBCiPlayer::RTMP;
	}

	$params->{'show_app'} = Slim::Plugin::Base->can('nonSNApps');

	my %fmtmap = (
		hls      => 'HLS',
		mp3      => 'MP3',
		flashaac => 'FlashAAC',
		flashmp3 => 'FlashMP3',
	);

	my @opts = (
		'hls,mp3,flashaac,flashmp3',
		'hls,mp3',
		'hls',
	);

	my @prefOpts = ();

	for my $opt (@opts) {
		push @prefOpts, { opt => $opt, disp => join(" > ", map { $fmtmap{$_} } split(/,/, $opt)) };
	}

	$params->{'opts'} = \@prefOpts;
}

1;
