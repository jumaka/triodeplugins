package Plugins::PlayDSD::Plugin;

use strict;

use base qw(Slim::Plugin::OPMLBased);

use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Player::TranscodingHelper;

use Plugins::PlayDSD::PlayerSettings;

my $prefs = preferences('plugin.playdsd');

my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.playdsd',
	'defaultLevel' => 'WARN',
	'description'  => 'PLUGIN_PLAYDSD',
});

sub initPlugin {
	my $class = shift;

	Plugins::PlayDSD::PlayerSettings->new;

	setupTranscoder();

	Slim::Control::Request::subscribe(\&initClientForDSD, [['client'],['new','reconnect']]);
}

sub setupTranscoder {
    my $client = $_[0];
	
    if (!$client) {
		my $profile = 'dsd-flc-*-*';
		$Slim::Player::TranscodingHelper::commandTable{$profile} = '[dsdplay] $START$ $END$ $FILE$ $RESAMPLE$';
		$Slim::Player::TranscodingHelper::capabilities{$profile} = {
			F => 'noArgs', T => 'START=-s %t', U => 'END=-e %v', D => 'RESAMPLE=-r %d'
		};
    } else {
		my $profile = 'dsd-flc-*-' . lc($client->macaddress);
		if ($prefs->client($client)->get('usedop')) {
			$Slim::Player::TranscodingHelper::commandTable{$profile} = '[dsdplay] -u $START$ $END$ $FILE$ $RESAMPLE$';
			$Slim::Player::TranscodingHelper::capabilities{$profile} = {
				F => 'noArgs', T => 'START=-s %t', U => 'END=-e %v', D => 'RESAMPLE=-r %d'
			};
		} else {
			delete $Slim::Player::TranscodingHelper::commandTable{$profile};
			delete $Slim::Player::TranscodingHelper::capabilities{$profile};
		}
    }
}

sub initClientForDSD {
    my $request = shift;
  
    setupTranscoder($request->client());
}

1;
