package Plugins::PlayDSD::PlayerSettings;

use strict;

use base qw(Slim::Web::Settings);

use Slim::Utils::Prefs;
use Slim::Utils::Log;
use Slim::Player::CapabilitiesHelper;

use Plugins::PlayDSD::Plugin;

my $prefs = preferences('plugin.playdsd');
my $log   = logger('plugin.playdsd');

sub getDisplayName {
    return 'PLUGIN_PLAYDSD';
}

sub needsClient {
    return 1;
}

sub name {
    return Slim::Web::HTTP::CSRF->protectName('PLUGIN_PLAYDSD');
}

sub page {
    return Slim::Web::HTTP::CSRF->protectURI('plugins/PlayDSD/settings/player.html');
}

sub prefs {
    my ($class, $client) = @_;
    return ($prefs->client($client), qw(usedop));
}

sub handler {
    my ($class, $client, $params, $callback, @args) = @_;
	
    my $usedop = $params->{'pref_usedop'} || 0;
	
    if ($params->{'saveSettings'}) {
		$prefs->client($client)->set('usedop', "$usedop");
		Plugins::PlayDSD::Plugin::setupTranscoder($client);
    }
	
	my %formats = map { $_ => 1 } Slim::Player::CapabilitiesHelper::supportedFormats($client);
	
	$params->{'native'} = $formats{'dff'} && $formats{'dsf'} ? 1 : 0;
	$params->{'dsdplay'} = Slim::Utils::Misc::findbin('dsdplay') ? 1: 0;
	
	$params->{'prefs'}->{'usedop'} = $prefs->client($client)->get('usedop');
	
    return $class->SUPER::handler($client, $params);
}

1;
