package Plugins::PlayDSD::Plugin;

use strict;

use base qw(Slim::Plugin::OPMLBased);

use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Player::TranscodingHelper;

use Plugins::PlayDSD::PlayerSettings;

my $prefs = preferences('plugin.playdsd');

my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.playdsd',
	'defaultLevel' => 'WARN',
	'description'  => 'PLUGIN_PLAYDSD',
});

sub initPlugin {
	my $class = shift;

	Plugins::PlayDSD::PlayerSettings->new;

	setupTranscoder();

	Slim::Control::Request::subscribe(\&initClientForDSD, [['client'],['new','reconnect']]);
}

sub setupTranscoder {
    my $client = $_[0];
	
	my $cmdTablePCM = '[dsdplay] $START$ $END$ $FILE$ $RESAMPLE$';
	my $cmdTableDoP = '[dsdplay] -u $START$ $END$ $FILE$ $RESAMPLE$';
	my $capabilities = {	F => 'noArgs', T => 'START=-s %t', U => 'END=-e %v', D => 'RESAMPLE=-r %d' };

    if (!$client) {
		my $dsf = 'dsf-flc-*-*';
		my $dff = 'dff-flc-*-*';
		$Slim::Player::TranscodingHelper::commandTable{ $dsf } = $cmdTablePCM;
		$Slim::Player::TranscodingHelper::capabilities{ $dsf } = $capabilities;
		$Slim::Player::TranscodingHelper::commandTable{ $dff } = $cmdTablePCM;
		$Slim::Player::TranscodingHelper::capabilities{ $dff } = $capabilities;
    } else {
		my $dsf = 'dsf-flc-*-' . lc($client->macaddress);
		my $dff = 'dff-flc-*-' . lc($client->macaddress);
		if ($prefs->client($client)->get('usedop')) {
			$Slim::Player::TranscodingHelper::commandTable{ $dsf } = $cmdTableDoP;
			$Slim::Player::TranscodingHelper::capabilities{ $dsf } = $capabilities;
			$Slim::Player::TranscodingHelper::commandTable{ $dsf } = $cmdTableDoP;
			$Slim::Player::TranscodingHelper::capabilities{ $dsf } = $capabilities;
		} else {
			delete $Slim::Player::TranscodingHelper::commandTable{ $dsf };
			delete $Slim::Player::TranscodingHelper::capabilities{ $dsf };
			delete $Slim::Player::TranscodingHelper::commandTable{ $dff };
			delete $Slim::Player::TranscodingHelper::capabilities{ $dff };
		}
    }
}

sub initClientForDSD {
    my $request = shift;
  
    setupTranscoder($request->client());
}

1;
